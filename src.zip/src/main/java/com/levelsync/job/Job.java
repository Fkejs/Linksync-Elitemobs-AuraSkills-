package com.levelsync.job;

import com.levelsync.job.JobRole;
import org.bukkit.Material;

public enum Job {
    IRON_GUARD("\u9244\u58c1\u9a0e\u58eb", "Iron Guard", Material.SHIELD, JobRole.TANK, "\u9ad8\u3044\u9632\u5fa1\u3068\u4ef2\u9593\u3092\u5b88\u308b\u76fe\u5f79"),
    DARK_KNIGHT("\u6697\u9ed2\u9a0e\u58eb", "Dark Knight", Material.NETHERITE_SWORD, JobRole.TANK, "\u95c7\u306e\u529b\u3067\u81ea\u3089\u3092\u5f37\u5316\u3059\u308b\u30bf\u30f3\u30af"),
    LIGHT_PRIEST("\u5149\u306e\u53f8\u796d", "Light Priest", Material.GOLDEN_APPLE, JobRole.HEALER, "\u5f37\u529b\u306a\u5358\u4f53\u30fb\u7bc4\u56f2\u56de\u5fa9\u3092\u64cd\u308b"),
    SPIRIT_CALLER("\u7cbe\u970a\u4f7f\u3044", "Spirit Caller", Material.BOOK, JobRole.HEALER, "\u7cbe\u970a\u3092\u547c\u3073\u51fa\u3057\u3066\u56de\u5fa9\u3068\u652f\u63f4\u3092\u884c\u3046"),
    BARRIER_MAGE("\u7d50\u754c\u8853\u5e2b", "Barrier Mage", Material.AMETHYST_SHARD, JobRole.HEALER, "\u30d0\u30ea\u30a2\u3068\u56de\u5fa9\u3092\u4e21\u7acb\u3059\u308b\u652f\u63f4\u5f79"),
    FIST_FIGHTER("\u62f3\u95d8\u58eb", "Fist Fighter", Material.LEATHER, JobRole.DPS, "\u9023\u6483\u3068\u81ea\u5df1\u5f37\u5316\u3067\u6226\u3046\u683c\u95d8\u5bb6"),
    LANCER("\u30e9\u30f3\u30b5\u30fc", "Lancer", Material.TRIDENT, JobRole.DPS, "\u69cd\u306b\u3088\u308b\u7a81\u9032\u3068\u9023\u7d9a\u653b\u6483"),
    ASSASSIN("\u6697\u6bba", "Assassin", Material.IRON_SWORD, JobRole.DPS, "\u9ad8\u3044\u6a5f\u52d5\u529b\u3068\u6025\u6240\u3092\u7a81\u304f\u6697\u6bba\u8005"),
    SAMURAI("\u4f8d", "Samurai", Material.DIAMOND_SWORD, JobRole.DPS, "\u5c45\u5408\u3068\u9ad8\u3044\u5358\u4f53\u706b\u529b\u3092\u8a87\u308b\u5263\u58eb"),
    NECROMANCER("\u30cd\u30af\u30ed\u30de\u30f3\u30b5\u30fc", "Necromancer", Material.NETHERITE_HOE, JobRole.DPS, "\u6b7b\u8005\u3092\u64cd\u308a\u9b42\u3092\u5208\u308a\u53d6\u308b\u95c7\u306e\u6226\u58eb"),
    BOW_HUNTER("\u5f13\u7375\u4eba", "Bow Hunter", Material.BOW, JobRole.DPS, "\u7cbe\u5bc6\u306a\u5f13\u8853\u3067\u9060\u8ddd\u96e2\u304b\u3089\u653b\u6483"),
    GEAR_SHOOTER("\u6a5f\u5de7\u5c04\u624b", "Gear Shooter", Material.CROSSBOW, JobRole.DPS, "\u6a5f\u68b0\u5175\u5668\u3092\u7528\u3044\u305f\u9060\u8ddd\u96e2\u706b\u529b"),
    RHYTHM_DANCER("\u5f8b\u52d5\u821e\u8005", "Rhythm Dancer", Material.FEATHER, JobRole.DPS, "\u8e0a\u308a\u3067\u5473\u65b9\u3092\u5f37\u5316\u3057\u3064\u3064\u653b\u6483\u3059\u308b"),
    FLAME_SORCERER("\u708e\u306e\u8853\u5e2b", "Flame Sorcerer", Material.BLAZE_ROD, JobRole.DPS, "\u5f37\u529b\u306a\u7bc4\u56f2\u706b\u708e\u9b54\u6cd5\u3092\u64cd\u308b"),
    BEAST_SUMMONER("\u7363\u53ec\u559a\u58eb", "Beast Summoner", Material.ENDER_PEARL, JobRole.DPS, "\u53ec\u559a\u7363\u3068\u5354\u529b\u3057\u3066\u6226\u3046"),
    ARCANE_DUELIST("\u9b54\u5263\u58eb", "Arcane Duelist", Material.REDSTONE, JobRole.DPS, "\u9b54\u6cd5\u3068\u8fd1\u63a5\u3092\u7d44\u307f\u5408\u308f\u305b\u305f\u6226\u95d8");

    private final String displayNameJa;
    private final String displayNameEn;
    private final Material icon;
    private final JobRole role;
    private final String description;

    private Job(String string2, String string3, Material material, JobRole jobRole, String string4) {
        this.displayNameJa = string2;
        this.displayNameEn = string3;
        this.icon = material;
        this.role = jobRole;
        this.description = string4;
    }

    public String getDisplayNameJa() {
        return this.displayNameJa;
    }

    public String getDisplayNameEn() {
        return this.displayNameEn;
    }

    public String getDisplayName() {
        return this.displayNameJa + " / " + this.displayNameEn;
    }

    public Material getIcon() {
        return this.icon;
    }

    public JobRole getRole() {
        return this.role;
    }

    public String getDescription() {
        return this.description;
    }
}
