package com.levelsync.job;

import com.levelsync.job.Job;
import com.levelsync.job.PlayerJobData;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class JobManager {
    private final JavaPlugin plugin;
    private final Map<UUID, PlayerJobData> dataMap = new ConcurrentHashMap<UUID, PlayerJobData>();
    private final File dataFolder;

    public JobManager(JavaPlugin javaPlugin) {
        this.plugin = javaPlugin;
        this.dataFolder = new File(javaPlugin.getDataFolder(), "jobdata");
        if (!this.dataFolder.exists()) {
            this.dataFolder.mkdirs();
        }
    }

    public PlayerJobData getData(UUID uUID2) {
        return this.dataMap.computeIfAbsent(uUID2, uUID -> {
            PlayerJobData playerJobData = this.load((UUID)uUID);
            return playerJobData != null ? playerJobData : new PlayerJobData((UUID)uUID);
        });
    }

    public PlayerJobData getData(Player player) {
        return this.getData(player.getUniqueId());
    }

    public void save(UUID uUID) {
        PlayerJobData playerJobData = this.dataMap.get(uUID);
        if (playerJobData == null) {
            return;
        }
        File file = new File(this.dataFolder, uUID.toString() + ".yml");
        YamlConfiguration yamlConfiguration = new YamlConfiguration();
        yamlConfiguration.set("currentJob", (Object)playerJobData.getCurrentJob().name());
        for (Job job : Job.values()) {
            yamlConfiguration.set("jobs." + job.name() + ".level", (Object)playerJobData.getLevel(job));
            yamlConfiguration.set("jobs." + job.name() + ".xp", (Object)playerJobData.getXp(job));
        }
        try {
            yamlConfiguration.save(file);
        }
        catch (IOException iOException) {
            this.plugin.getLogger().warning("Failed to save job data for " + String.valueOf(uUID) + ": " + iOException.getMessage());
        }
    }

    public void saveAll() {
        for (UUID uUID : this.dataMap.keySet()) {
            this.save(uUID);
        }
    }

    private PlayerJobData load(UUID uUID) {
        File file = new File(this.dataFolder, uUID.toString() + ".yml");
        if (!file.exists()) {
            return null;
        }
        YamlConfiguration yamlConfiguration = YamlConfiguration.loadConfiguration((File)file);
        PlayerJobData playerJobData = new PlayerJobData(uUID);
        String string = yamlConfiguration.getString("currentJob", "IRON_GUARD");
        try {
            playerJobData.setCurrentJob(Job.valueOf(string));
        }
        catch (IllegalArgumentException illegalArgumentException) {
            playerJobData.setCurrentJob(Job.IRON_GUARD);
        }
        ConfigurationSection configurationSection = yamlConfiguration.getConfigurationSection("jobs");
        if (configurationSection != null) {
            for (String string2 : configurationSection.getKeys(false)) {
                try {
                    Job job = Job.valueOf(string2);
                    int n = configurationSection.getInt(string2 + ".level", 1);
                    double d = configurationSection.getDouble(string2 + ".xp", 0.0);
                    playerJobData.setLevel(job, n);
                    playerJobData.setXp(job, d);
                }
                catch (IllegalArgumentException illegalArgumentException) {}
            }
        }
        return playerJobData;
    }

    public void unload(UUID uUID) {
        this.save(uUID);
        this.dataMap.remove(uUID);
    }

    public void addXpToCurrentJob(Player player, double d) {
        PlayerJobData playerJobData = this.getData(player);
        Job job = playerJobData.getCurrentJob();
        int n = playerJobData.getLevel(job);
        playerJobData.addXp(job, d);
        int n2 = playerJobData.getLevel(job);
        if (n2 > n) {
            player.sendMessage("\u00a76\u00a7l\u30b8\u30e7\u30d6\u30ec\u30d9\u30eb\u30a2\u30c3\u30d7\uff01 \u00a7e" + job.getDisplayName() + " \u00a7f\u304c \u00a7aLv." + n2 + " \u00a7f\u306b\u306a\u308a\u307e\u3057\u305f\uff01");
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.2f);
        }
    }
}
