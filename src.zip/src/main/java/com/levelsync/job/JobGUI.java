package com.levelsync.job;

import com.levelsync.job.Job;
import com.levelsync.job.JobManager;
import com.levelsync.job.JobRole;
import com.levelsync.job.JobSkill;
import com.levelsync.job.PlayerJobData;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class JobGUI {
    public static final String TITLE = "\u00a78\u00a7lJob System \u00a77- \u00a7f\u30b8\u30e7\u30d6\u9078\u629e";
    private static final Set<Job> ABOLISHED = EnumSet.of(Job.RHYTHM_DANCER, Job.BEAST_SUMMONER, Job.ARCANE_DUELIST);

    public static boolean isAbolished(Job job) {
        return job != null && ABOLISHED.contains((Object)job);
    }

    public static void open(Player player, JobManager jobManager) {
        PlayerJobData playerJobData = jobManager.getData(player);
        Inventory inventory = Bukkit.createInventory(null, (int)54, (String)TITLE);
        ItemStack itemStack = new ItemStack(Material.NETHER_STAR);
        ItemMeta itemMeta = itemStack.getItemMeta();
        if (itemMeta != null) {
            itemMeta.setDisplayName("\u00a76\u00a7l\u73fe\u5728\u306e\u30b8\u30e7\u30d6");
            Job job = playerJobData.getCurrentJob();
            ArrayList<Object> arrayList = new ArrayList<Object>();
            arrayList.add("\u00a7e" + job.getDisplayName());
            arrayList.add("\u00a77\u30ed\u30fc\u30eb: " + job.getRole().getDisplay());
            arrayList.add("\u00a77\u30ec\u30d9\u30eb: \u00a7f" + playerJobData.getLevel(job));
            arrayList.add(String.format("\u00a77\u7d4c\u9a13\u5024: \u00a7f%.1f%%", playerJobData.getXpProgressPercent(job)));
            if (JobGUI.isAbolished(job)) {
                arrayList.add("");
                arrayList.add("\u00a7c\u3053\u306e\u30b8\u30e7\u30d6\u306f\u5ec3\u6b62\u3055\u308c\u307e\u3057\u305f");
                arrayList.add("\u00a7e\u5225\u306e\u30b8\u30e7\u30d6\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044");
            }
            itemMeta.setLore(arrayList);
            itemStack.setItemMeta(itemMeta);
        }
        inventory.setItem(4, itemStack);
        JobGUI.placeRoleLabel(inventory, 9, JobRole.TANK);
        JobGUI.placeRoleLabel(inventory, 18, JobRole.HEALER);
        JobGUI.placeRoleLabel(inventory, 27, JobRole.DPS);
        int n = 10;
        int n2 = 19;
        int n3 = 28;
        block5: for (Job job : Job.values()) {
            if (JobGUI.isAbolished(job)) continue;
            ItemStack itemStack2 = JobGUI.createJobItem(job, playerJobData);
            switch (job.getRole()) {
                case TANK: {
                    if (n > 16) continue block5;
                    inventory.setItem(n++, itemStack2);
                    continue block5;
                }
                case HEALER: {
                    if (n2 > 25) continue block5;
                    inventory.setItem(n2++, itemStack2);
                    continue block5;
                }
                case DPS: {
                    if (n3 > 34) continue block5;
                    inventory.setItem(n3++, itemStack2);
                }
            }
        }
        ItemStack itemStack3 = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta itemMeta2 = itemStack3.getItemMeta();
        if (itemMeta2 != null) {
            itemMeta2.setDisplayName(" ");
            itemStack3.setItemMeta(itemMeta2);
        }
        for (int i = 0; i < 54; ++i) {
            if (inventory.getItem(i) != null) continue;
            inventory.setItem(i, itemStack3);
        }
        player.openInventory(inventory);
    }

    private static void placeRoleLabel(Inventory inventory, int n, JobRole jobRole) {
        Material material = switch (jobRole) {
            default -> throw new MatchException(null, null);
            case JobRole.TANK -> Material.BLUE_STAINED_GLASS_PANE;
            case JobRole.HEALER -> Material.GREEN_STAINED_GLASS_PANE;
            case JobRole.DPS -> Material.RED_STAINED_GLASS_PANE;
        };
        ItemStack itemStack = new ItemStack(material);
        ItemMeta itemMeta = itemStack.getItemMeta();
        if (itemMeta != null) {
            itemMeta.setDisplayName(jobRole.getDisplay());
            itemStack.setItemMeta(itemMeta);
        }
        inventory.setItem(n, itemStack);
    }

    private static ItemStack createJobItem(Job job, PlayerJobData playerJobData) {
        ItemStack itemStack = new ItemStack(job.getIcon());
        ItemMeta itemMeta = itemStack.getItemMeta();
        if (itemMeta == null) {
            return itemStack;
        }
        boolean bl = playerJobData.getCurrentJob() == job;
        String string = bl ? "\u00a7a\u00a7l\u25b6 " : "\u00a7f";
        itemMeta.setDisplayName(string + job.getDisplayName());
        ArrayList<Object> arrayList = new ArrayList<Object>();
        arrayList.add("\u00a77\u30ed\u30fc\u30eb: " + job.getRole().getDisplay());
        arrayList.add("\u00a77" + job.getDescription());
        arrayList.add("");
        arrayList.add("\u00a7b\u30b9\u30ad\u30eb: \u00a7f" + JobSkill.getSkillName(job));
        arrayList.add("\u00a78" + JobSkill.getSkillDescription(job));
        arrayList.add("\u00a78\u30b9\u30cb\u30fc\u30af+\u53f3\u30af\u30ea\u30c3\u30af\u3067\u767a\u52d5");
        arrayList.add("");
        arrayList.add("\u00a7e\u30ec\u30d9\u30eb: \u00a7f" + playerJobData.getLevel(job));
        if (playerJobData.getLevel(job) < 100) {
            arrayList.add(String.format("\u00a7e\u7d4c\u9a13\u5024: \u00a7f%.1f%%", playerJobData.getXpProgressPercent(job)));
        } else {
            arrayList.add("\u00a76\u00a7lMAX LEVEL");
        }
        arrayList.add("");
        if (bl) {
            arrayList.add("\u00a7a\u2713 \u73fe\u5728\u3053\u306e\u30b8\u30e7\u30d6\u3067\u3059");
        } else {
            arrayList.add("\u00a7e\u30af\u30ea\u30c3\u30af\u3067\u3053\u306e\u30b8\u30e7\u30d6\u306b\u5909\u66f4");
        }
        itemMeta.setLore(arrayList);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }
}
