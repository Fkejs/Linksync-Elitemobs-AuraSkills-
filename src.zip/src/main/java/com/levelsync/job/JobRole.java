package com.levelsync.job;

import org.bukkit.ChatColor;

public enum JobRole {
    TANK("\u30bf\u30f3\u30af", "Tank", ChatColor.BLUE),
    HEALER("\u30d2\u30fc\u30e9\u30fc", "Healer", ChatColor.GREEN),
    DPS("DPS", "DPS", ChatColor.RED);

    private final String nameJa;
    private final String nameEn;
    private final ChatColor color;

    private JobRole(String string2, String string3, ChatColor chatColor) {
        this.nameJa = string2;
        this.nameEn = string3;
        this.color = chatColor;
    }

    public String getNameJa() {
        return this.nameJa;
    }

    public String getNameEn() {
        return this.nameEn;
    }

    public String getDisplay() {
        return String.valueOf(this.color) + this.nameJa + " / " + this.nameEn;
    }

    public ChatColor getColor() {
        return this.color;
    }
}
