package com.levelsync.job;

import com.levelsync.job.Job;
import java.util.EnumMap;
import java.util.Map;
import java.util.UUID;

public class PlayerJobData {
    private final UUID uuid;
    private Job currentJob;
    private final Map<Job, Integer> levels = new EnumMap<Job, Integer>(Job.class);
    private final Map<Job, Double> xp = new EnumMap<Job, Double>(Job.class);

    public PlayerJobData(UUID uUID) {
        this.uuid = uUID;
        for (Job job : Job.values()) {
            this.levels.put(job, 1);
            this.xp.put(job, 0.0);
        }
        this.currentJob = Job.IRON_GUARD;
    }

    public UUID getUuid() {
        return this.uuid;
    }

    public Job getCurrentJob() {
        return this.currentJob;
    }

    public void setCurrentJob(Job job) {
        if (job != null) {
            this.currentJob = job;
        }
    }

    public int getLevel(Job job) {
        return this.levels.getOrDefault((Object)job, 1);
    }

    public void setLevel(Job job, int n) {
        this.levels.put(job, Math.max(1, Math.min(n, 100)));
    }

    public double getXp(Job job) {
        return this.xp.getOrDefault((Object)job, 0.0);
    }

    public void setXp(Job job, double d) {
        this.xp.put(job, Math.max(0.0, d));
    }

    public void addXp(Job job, double d) {
        int n;
        if (d <= 0.0) {
            return;
        }
        double d2 = this.getXp(job);
        d2 += d;
        for (n = this.getLevel(job); n < 100 && d2 >= PlayerJobData.getXpRequired(n); d2 -= PlayerJobData.getXpRequired(n), ++n) {
        }
        if (n >= 100) {
            d2 = 0.0;
            n = 100;
        }
        this.setLevel(job, n);
        this.setXp(job, d2);
    }

    public static double getXpRequired(int n) {
        return Math.floor(100.0 * Math.pow(n, 1.5));
    }

    public double getXpProgressPercent(Job job) {
        int n = this.getLevel(job);
        if (n >= 100) {
            return 100.0;
        }
        double d = PlayerJobData.getXpRequired(n);
        if (d <= 0.0) {
            return 0.0;
        }
        return this.getXp(job) / d * 100.0;
    }
}
