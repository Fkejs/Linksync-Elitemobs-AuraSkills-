package com.levelsync.job;

import com.levelsync.LevelSync;
import com.levelsync.job.CitizensSummonHelper;
import com.levelsync.job.Job;
import com.levelsync.job.JobManager;
import com.levelsync.job.JobSkillListener;
import com.levelsync.job.NecroReplacement;
import com.levelsync.job.SummonLevelSync;
import com.magmaguy.elitemobs.playerdata.database.PlayerData;
import com.magmaguy.elitemobs.skills.SkillType;
import dev.aurelium.auraskills.api.AuraSkillsApi;
import dev.aurelium.auraskills.api.skill.Skill;
import dev.aurelium.auraskills.api.skill.Skills;
import dev.aurelium.auraskills.api.user.SkillsUser;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.AnimalTamer;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.IronGolem;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.entity.Skeleton;
import org.bukkit.entity.WitherSkeleton;
import org.bukkit.entity.Wolf;
import org.bukkit.entity.Zombie;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

public class JobSkill {
    public static final long DEFAULT_COOLDOWN_MS = 8000L;
    private static final Map<UUID, Integer> samuraiCombo = new ConcurrentHashMap<UUID, Integer>();
    private static final Map<UUID, Integer> lancerChain = new ConcurrentHashMap<UUID, Integer>();

    public static String getSkillName(Job job) {
        return switch (job) {
            default -> throw new MatchException(null, null);
            case Job.IRON_GUARD -> "\u9244\u58c1\u306e\u5b88\u8b77";
            case Job.DARK_KNIGHT -> "\u6697\u5f71\u53cc\u8eab";
            case Job.LIGHT_PRIEST -> "\u5149\u306e\u7652\u3057";
            case Job.SPIRIT_CALLER -> "\u7cbe\u970a\u306e\u52a0\u8b77";
            case Job.BARRIER_MAGE -> "\u7d50\u754c\u5c55\u958b";
            case Job.FIST_FIGHTER -> "\u9023\u6483\u7834\u7815";
            case Job.LANCER -> "\u8cab\u901a\u9023\u7a81";
            case Job.ASSASSIN -> "\u5f71\u8d70\u308a";
            case Job.SAMURAI -> "\u56db\u6bb5\u306e\u578b";
            case Job.NECROMANCER -> "\u6b7b\u8005\u306e\u76ee\u899a\u3081";
            case Job.BOW_HUNTER -> "\u8cab\u901a\u77e2";
            case Job.GEAR_SHOOTER -> "\u70b8\u88c2\u5f3e";
            case Job.RHYTHM_DANCER -> "\u9f13\u821e\u306e\u821e";
            case Job.FLAME_SORCERER -> "\u708e\u7206";
            case Job.BEAST_SUMMONER -> "\u7363\u53ec\u6765";
            case Job.ARCANE_DUELIST -> "\u9b54\u5263\u9583";
        };
    }

    public static String getSkillDescription(Job job) {
        return switch (job) {
            default -> throw new MatchException(null, null);
            case Job.IRON_GUARD -> "\u30d8\u30a4\u30c8\u96c6\u4e2d+\u8010\u6027\uff08\u5e38\u6642\uff1a\u65a7\u5f37\u5316\uff0f\u5263\u5f31\u4f53\uff09";
            case Job.DARK_KNIGHT -> "\u81ea\u8eab\u88c5\u5099\u306e\u5206\u8eab\u3092\u53ec\u559a\uff08\u9ad8\u30ec\u30d9\u30eb\u30672\u4f53\uff0f\u5263\u6240\u6301\uff0f\u30ec\u30d9\u30eb\u5b8c\u5168\u53cd\u6620\uff09";
            case Job.LIGHT_PRIEST -> "\u81ea\u8eab\u3068\u5468\u56f2\u30d7\u30ec\u30a4\u30e4\u30fc\u3092\u56de\u5fa9";
            case Job.SPIRIT_CALLER -> "\u5468\u56f2\u30d7\u30ec\u30a4\u30e4\u30fc\u306b\u518d\u751f\u52b9\u679c";
            case Job.BARRIER_MAGE -> "\u81ea\u8eab\u306b\u30c0\u30e1\u30fc\u30b8\u8efd\u6e1b\u30d0\u30ea\u30a2";
            case Job.FIST_FIGHTER -> "\u524d\u65b9\u3078\u9023\u7d9a\u7bc4\u56f2\u653b\u6483\uff08\u5e38\u6642\uff1a\u7d20\u624b\u5f37\u5316\uff09";
            case Job.LANCER -> "\u524d\u65b9\u7a81\u9032\u306e\u8cab\u901a\u653b\u6483\uff08\u6700\u59273\u9023\u7d9a\uff0f\u5e38\u6642\uff1a\u69cd\u5f37\u5316\uff09";
            case Job.ASSASSIN -> "\u900f\u660e\u5316+\u52a0\u901f\uff08\u5e38\u6642\uff1a\u5263\u5f37\u5316\uff09";
            case Job.SAMURAI -> "4\u6bb5\u968e\u3067\u5909\u5316\u3059\u308b\u578b\uff08\u5e38\u6642\uff1a\u5263\u5f37\u5316\uff09";
            case Job.NECROMANCER -> "\u4eba\u578b\u5f93\u50d5\u3092\u53ec\u559a\uff08\u9632\u5177\u306f\u81ea\u8eab\u88c5\u5099\u3092\u53cd\u6620\uff0f\u6b66\u5668\u306f\u56fa\u5b9a\uff09";
            case Job.BOW_HUNTER -> "\u524d\u65b9\u7bc4\u56f2\u5c04\u6483\u5f8c\u306b\u9ad8\u706b\u529b\u8cab\u901a\u77e2\uff08\u5e38\u6642\uff1a\u5f13\u5f37\u5316\uff0f\u5263\u65a7\u5f31\u4f53\uff09";
            case Job.GEAR_SHOOTER -> "\u30a2\u30a4\u30a2\u30f3\u30b4\u30fc\u30ec\u30e0\u3092\u53ec\u559a\uff08\u7206\u767aTNT\u3068\u9ad8\u706b\u529b\u96ea\u7389\uff09";
            case Job.RHYTHM_DANCER -> "\u5468\u56f2\u30d7\u30ec\u30a4\u30e4\u30fc\u306e\u653b\u6483\u529b\u3092\u4e00\u6642\u4e0a\u6607";
            case Job.FLAME_SORCERER -> "\u524d\u65b9\u306b\u706b\u708e\u7206\u767a\u3092\u767a\u751f";
            case Job.BEAST_SUMMONER -> "\u72fc\u3092\u6700\u59276\u4f53\u53ec\u559a";
            case Job.ARCANE_DUELIST -> "\u9b54\u6cd5\u306e\u65ac\u6483\u3092\u98db\u3070\u3059";
        };
    }

    public static boolean cast(Player player, Job job) {
        World world = player.getWorld();
        Location location = player.getLocation();
        int[] nArray = JobSkill.getLevels(player, job);
        int n = nArray[0];
        int n2 = nArray[1];
        double d = 1.0 + (double)n * 0.01 + (double)n2 * 0.015;
        switch (job) {
            case IRON_GUARD: {
                int n3 = Math.min(3, 1 + (n + n2) / 40);
                int n4 = 80 + n + n2;
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, n4, n3));
                player.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, n4, Math.min(3, n3)));
                double d2 = 4.0 + (double)(n + n2) * 0.0;
                int n5 = 0;
                for (Entity entity : player.getNearbyEntities(d2, 4.0, d2)) {
                    if (!(entity instanceof Mob)) continue;
                    Mob mob = (Mob)entity;
                    if (entity instanceof Player) continue;
                    mob.setTarget((LivingEntity)player);
                    mob.damage(0.1, (Entity)player);
                    world.spawnParticle(Particle.ANGRY_VILLAGER, mob.getLocation().add(0.0, 1.2, 0.0), 3, 0.2, 0.1, 0.2, 0.0);
                    ++n5;
                }
                world.playSound(location, Sound.ITEM_SHIELD_BLOCK, 1.0f, 0.8f);
                world.spawnParticle(Particle.CRIT, location, 30, 1.5, 0.5, 1.5, 0.06);
                player.sendMessage("\u00a7b[\u9244\u58c1\u306e\u5b88\u8b77] \u00a7f" + n5 + " \u4f53\u306e\u6575\u306e\u30d8\u30a4\u30c8\u3092\u96c6\u3081\u305f");
                break;
            }
            case DARK_KNIGHT: {
                JobSkill.spawnShadowClone(player);
                world.playSound(location, Sound.ENTITY_WITHER_SPAWN, 0.6f, 1.4f);
                world.spawnParticle(Particle.SMOKE, location, 40, 1.0, 1.0, 1.0, 0.05);
                world.spawnParticle(Particle.SOUL, location, 20, 0.8, 1.0, 0.8, 0.01);
                break;
            }
            case LIGHT_PRIEST: {
                double d3 = JobSkill.scale(n, n2, 6.0, 0.08, 0.12);
                double d4 = JobSkill.scale(n, n2, 4.0, 0.035, 0.1);
                double d5 = 5.0 + (double)(n + n2) * 0.03;
                player.setHealth(Math.min(player.getMaxHealth(), player.getHealth() + d3));
                for (Entity entity : player.getNearbyEntities(d5, 3.0, d5)) {
                    if (!(entity instanceof Player)) continue;
                    Player player2 = (Player)entity;
                    player2.setHealth(Math.min(player2.getMaxHealth(), player2.getHealth() + d4));
                    player2.spawnParticle(Particle.HEART, player2.getLocation().add(0.0, 1.5, 0.0), 5, 0.3, 0.3, 0.3, 0.0);
                }
                world.playSound(location, Sound.BLOCK_BEACON_ACTIVATE, 0.8f, 1.5f);
                world.spawnParticle(Particle.END_ROD, location, 20, 1.0, 1.0, 1.0, 0.05);
                break;
            }
            case SPIRIT_CALLER: {
                int n6 = Math.min(2, (n + n2) / 50);
                int n7 = 100 + n + n2;
                player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, n7, 1 + n6));
                double d6 = 2.5 + (double)(n + n2) * 0.03;
                for (Entity entity : player.getNearbyEntities(d6, 1.5, d6)) {
                    if (!(entity instanceof Player)) continue;
                    Player player3 = (Player)entity;
                    player3.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, n7 - 20, n6));
                }
                world.playSound(location, Sound.ENTITY_ALLAY_AMBIENT_WITHOUT_ITEM, 1.0f, 1.2f);
                world.spawnParticle(Particle.HAPPY_VILLAGER, location, 25, 1.5, 1.0, 1.5, 0.1);
                break;
            }
            case BARRIER_MAGE: {
                int n8 = Math.min(4, 1 + (n + n2) / 35);
                int n9 = (int)(100.0 + (double)n * 1.2 + (double)n2);
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, n9, n8));
                player.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, n9, Math.min(4, n8)));
                world.playSound(location, Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1.0f, 0.7f);
                world.spawnParticle(Particle.ENCHANT, location.clone().add(0.0, 1.0, 0.0), 40, 1.0, 1.0, 1.0, 0.5);
                break;
            }
            case FIST_FIGHTER: {
                double d7 = JobSkill.scale(n, n2, 3.0, 0.1, 0.22);
                double d8 = 4.0 + (double)(n + n2) * 0.015;
                double d9 = 1.6 + (double)(n + n2) * 0.01;
                int n10 = Math.min(4, 3 + (n + n2) / 45);
                Plugin plugin = Bukkit.getPluginManager().getPlugin("LevelSync");
                for (int i = 0; i < n10; ++i) {
                    int n11 = i;
                    Bukkit.getScheduler().runTaskLater(plugin, () -> {
                        Location location = player.getEyeLocation();
                        Vector vector = location.getDirection().normalize();
                        for (double d4 = 1.0; d4 <= d8; d4 += 0.9) {
                            Location location2 = location.clone().add(vector.clone().multiply(d4));
                            for (Entity entity : world.getNearbyEntities(location2, d9, d9, d9)) {
                                if (!(entity instanceof LivingEntity)) continue;
                                LivingEntity livingEntity = (LivingEntity)entity;
                                if (entity == player || entity instanceof ArmorStand) continue;
                                livingEntity.damage(d7, (Entity)player);
                                world.spawnParticle(Particle.CRIT, livingEntity.getLocation().add(0.0, 1.0, 0.0), 6, 0.25, 0.25, 0.25, 0.02);
                            }
                            world.spawnParticle(Particle.SWEEP_ATTACK, location2, 1, 0.0, 0.0, 0.0, 0.0);
                        }
                        world.playSound(player.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 0.9f, 1.1f + (float)n11 * 0.05f);
                    }, (long)i * 5L);
                }
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 50 + n / 2, Math.min(2, (n + n2) / 50)));
                break;
            }
            case LANCER: {
                UUID uUID = player.getUniqueId();
                int n12 = lancerChain.getOrDefault(uUID, 3);
                if (n12 <= 0) {
                    n12 = 3;
                }
                double d10 = 1.6 + Math.min(1.3, (double)(n + n2) * 0.006);
                Vector vector = player.getLocation().getDirection().normalize().multiply(d10).setY(0.22);
                player.setVelocity(vector);
                double d11 = JobSkill.scale(n, n2, 5.5, 0.11, 0.16);
                double d12 = 5.0 + (double)(n + n2) * 0.03;
                Plugin plugin = Bukkit.getPluginManager().getPlugin("LevelSync");
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    Location location = player.getEyeLocation();
                    Vector vector = location.getDirection().normalize();
                    HashSet<UUID> hashSet = new HashSet<UUID>();
                    for (double d3 = 1.0; d3 <= d12; d3 += 0.7) {
                        Location location2 = location.clone().add(vector.clone().multiply(d3));
                        for (Entity entity : world.getNearbyEntities(location2, 1.2, 1.2, 1.2)) {
                            if (!(entity instanceof LivingEntity)) continue;
                            LivingEntity livingEntity = (LivingEntity)entity;
                            if (entity == player || entity instanceof ArmorStand || !hashSet.add(entity.getUniqueId())) continue;
                            livingEntity.damage(d11, (Entity)player);
                            world.spawnParticle(Particle.CRIT, livingEntity.getLocation().add(0.0, 1.0, 0.0), 8, 0.3, 0.3, 0.3, 0.03);
                        }
                    }
                }, 4L);
                world.playSound(location, Sound.ENTITY_ENDER_DRAGON_FLAP, 0.7f, 1.4f);
                if (--n12 > 0) {
                    lancerChain.put(uUID, n12);
                    player.sendMessage("\u00a7b[\u8cab\u901a\u9023\u7a81] \u00a7f\u9023\u7d9a\u6b8b\u308a \u00a7e" + n12 + "\u00a7f \u56de\uff08\u3059\u3050\u306b\u518d\u767a\u52d5\u53ef\uff09");
                    break;
                }
                lancerChain.put(uUID, 3);
                player.sendMessage("\u00a7b[\u8cab\u901a\u9023\u7a81] \u00a7f3\u9023\u6483\u5b8c\u4e86");
                break;
            }
            case ASSASSIN: {
                int n13 = (int)(60.0 + (double)n * 0.8 + (double)n2 * 0.6);
                int n14 = Math.min(3, 1 + (n + n2) / 45);
                player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, n13, 0));
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, n13, n14));
                world.playSound(location, Sound.ENTITY_ENDERMAN_TELEPORT, 0.8f, 1.4f);
                world.spawnParticle(Particle.SMOKE, location, 20, 0.5, 1.0, 0.5, 0.05);
                break;
            }
            case SAMURAI: {
                UUID uUID = player.getUniqueId();
                int n15 = samuraiCombo.getOrDefault(uUID, 0);
                double d13 = JobSkill.scale(n, n2, 2.0, 0.07, 0.18);
                double d14 = 3.5 + (double)(n + n2) * 0.02;
                switch (n15) {
                    case 0: {
                        JobSkill.damageInFront(player, d14 + 0.8, d13 * 1.15);
                        world.playSound(location, Sound.ENTITY_PLAYER_ATTACK_CRIT, 1.0f, 0.7f);
                        world.spawnParticle(Particle.SWEEP_ATTACK, location.clone().add(player.getLocation().getDirection().multiply(2)).add(0.0, 1.0, 0.0), 8, 0.8, 0.3, 0.8, 0.0);
                        player.sendMessage("\u00a7e[\u56db\u6bb5\u306e\u578b] \u00a7f\u58f1\u306e\u578b\uff1a\u5e83\u7bc4\u56f2\u65ac\u6483");
                        break;
                    }
                    case 1: {
                        LivingEntity livingEntity = JobSkill.getFrontTarget(player, d14);
                        if (livingEntity != null) {
                            livingEntity.damage(d13 * 1.35, (Entity)player);
                            livingEntity.setFireTicks(60 + n + n2 / 2);
                            world.spawnParticle(Particle.FLAME, livingEntity.getLocation().add(0.0, 1.0, 0.0), 25, 0.4, 0.6, 0.4, 0.02);
                        } else {
                            JobSkill.damageInFront(player, d14 * 0.7, d13);
                        }
                        world.playSound(location, Sound.ITEM_FIRECHARGE_USE, 1.0f, 1.0f);
                        player.sendMessage("\u00a76[\u56db\u6bb5\u306e\u578b] \u00a7f\u5f10\u306e\u578b\uff1a\u708e\u65ac\u30fb\u3084\u3051\u3069");
                        break;
                    }
                    case 2: {
                        Location location2 = player.getEyeLocation();
                        Vector vector = location2.getDirection().normalize();
                        for (double d15 = 1.0; d15 <= d14; d15 += 0.8) {
                            Location location3 = location2.clone().add(vector.clone().multiply(d15));
                            for (Entity entity : world.getNearbyEntities(location3, 1.0, 1.4, 1.4)) {
                                if (!(entity instanceof LivingEntity)) continue;
                                LivingEntity livingEntity = (LivingEntity)entity;
                                if (entity == player || entity instanceof ArmorStand) continue;
                                livingEntity.damage(d13 * 0.95, (Entity)player);
                                livingEntity.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 50 + n / 2, 255));
                                livingEntity.setVelocity(new Vector(0, 0, 0));
                                world.spawnParticle(Particle.SNOWFLAKE, livingEntity.getLocation().add(0.0, 1.0, 0.0), 12, 0.3, 0.5, 0.3, 0.01);
                            }
                        }
                        world.playSound(location, Sound.BLOCK_GLASS_BREAK, 1.0f, 0.7f);
                        player.sendMessage("\u00a7b[\u56db\u6bb5\u306e\u578b] \u00a7f\u53c2\u306e\u578b\uff1a\u6c37\u7d50\u9ebb\u75fa");
                        break;
                    }
                    default: {
                        double d16 = 5.0 + (double)(n + n2) * 0.03;
                        for (Entity entity : player.getNearbyEntities(d16, 3.0, d16)) {
                            if (!(entity instanceof LivingEntity)) continue;
                            LivingEntity livingEntity = (LivingEntity)entity;
                            if (entity instanceof Player) continue;
                            livingEntity.damage(d13 * 1.1, (Entity)player);
                            world.spawnParticle(Particle.CHERRY_LEAVES, livingEntity.getLocation().add(0.0, 1.0, 0.0), 10, 0.4, 0.5, 0.4, 0.02);
                        }
                        world.spawnParticle(Particle.CHERRY_LEAVES, location.clone().add(0.0, 1.0, 0.0), 50, d16 * 0.5, 1.0, d16 * 0.5, 0.02);
                        world.playSound(location, Sound.BLOCK_CHERRY_LEAVES_BREAK, 1.0f, 1.2f);
                        player.sendMessage("\u00a7d[\u56db\u6bb5\u306e\u578b] \u00a7f\u8086\u306e\u578b\uff1a\u685c\u5439\u96ea\u65ac \u2192 \u58f1\u3078\u623b\u308b");
                    }
                }
                samuraiCombo.put(uUID, (n15 + 1) % 4);
                break;
            }
            case NECROMANCER: {
                NecroReplacement.spawnUndeadSkulls((Player)player);
                world.playSound(location, Sound.ENTITY_WITHER_SPAWN, 0.5f, 1.6f);
                world.spawnParticle(Particle.SOUL, location, 30, 1.2, 1.0, 1.2, 0.03);
                world.spawnParticle(Particle.SMOKE, location, 20, 1.0, 0.8, 1.0, 0.02);
                break;
            }
            case BOW_HUNTER: {
                Vector vector = player.getLocation().getDirection().normalize();
                double d17 = JobSkill.scale(n, n2, 3.0, 0.06, 0.1);
                int n16 = Math.min(3, 3 + (n + n2) / 35);
                for (int i = 0; i < n16; ++i) {
                    double d18 = ((double)i - (double)n16 / 2.0) * 0.12;
                    Vector vector2 = vector.clone();
                    double d19 = Math.cos(d18);
                    double d20 = Math.sin(d18);
                    double d21 = vector2.getX() * d19 - vector2.getZ() * d20;
                    double d22 = vector2.getX() * d20 + vector2.getZ() * d19;
                    vector2.setX(d21).setZ(d22).normalize();
                    Arrow arrow = (Arrow)player.launchProjectile(Arrow.class);
                    arrow.setVelocity(vector2.multiply(2.4 + Math.min(1.0, (double)n2 * 0.008)));
                    arrow.setDamage(d17);
                    arrow.setPierceLevel(1);
                }
                double d23 = JobSkill.scale(n, n2, 8.0, 0.07, 0.2);
                Plugin plugin = Bukkit.getPluginManager().getPlugin("LevelSync");
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    Arrow arrow = (Arrow)player.launchProjectile(Arrow.class);
                    arrow.setVelocity(player.getLocation().getDirection().normalize().multiply(3.6));
                    arrow.setPierceLevel(Math.min(12, 5 + (n + n2) / 15));
                    arrow.setDamage(d23);
                    arrow.setCritical(true);
                    arrow.setGlowing(true);
                    world.playSound(player.getLocation(), Sound.ENTITY_ARROW_SHOOT, 1.0f, 0.6f);
                }, 6L);
                world.playSound(location, Sound.ENTITY_ARROW_SHOOT, 1.0f, 1.1f);
                break;
            }
            case GEAR_SHOOTER: {
                int n17 = Math.min(5, 2 + (n + n2) / 40);
                double d24 = JobSkill.scale(n, n2, 40.0, 0.8, 1.0);
                int n18 = 300 + n * 2 + n2 * 2;
                double d25 = JobSkill.scale(n, n2, 6.0, 0.06, 0.18);
                if (false) {
                    CitizensSummonHelper.spawnMany((Player)player, (Location)location, (int)n17, (double)2.0, summonSpec -> {
                        summonSpec.name = "\u00a76\u6a5f\u5de7\u5175";
                        summonSpec.hp = d24;
                        summonSpec.damage = d25;
                        summonSpec.lifeTicks = n18;
                        summonSpec.jobLevel = n;
                        summonSpec.ranged = true;
                        summonSpec.style = "ranged";
                        summonSpec.helmet = new ItemStack(Material.IRON_HELMET);
                        summonSpec.chest = new ItemStack(Material.IRON_CHESTPLATE);
                        summonSpec.legs = new ItemStack(Material.IRON_LEGGINGS);
                        summonSpec.boots = new ItemStack(Material.IRON_BOOTS);
                        summonSpec.hand = new ItemStack(Material.CROSSBOW);
                    });
                    player.sendMessage("\u00a76[\u6a5f\u5de7\u5c04\u624b] \u00a7f\u6a5f\u5de7\u5175 x" + n17 + " \u3092\u53ec\u559a");
                    break;
                }
                Plugin plugin = Bukkit.getPluginManager().getPlugin("LevelSync");
                for (int i = 0; i < n17; ++i) {
                    double d26 = Math.PI * 2 * (double)i / (double)n17;
                    Location location4 = location.clone().add(Math.cos(d26) * 2.0, 0.0, Math.sin(d26) * 2.0);
                    IronGolem ironGolem = (IronGolem)world.spawnEntity(location4, EntityType.IRON_GOLEM);
                    ironGolem.setCustomName("\u00a76\u6a5f\u5de7\u30b4\u30fc\u30ec\u30e0");
                    ironGolem.setCustomNameVisible(true);
                    ironGolem.setPlayerCreated(true);
                    ironGolem.addScoreboardTag("levelsync_summon");
                    if (ironGolem.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null) {
                        ironGolem.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(d24);
                        ironGolem.setHealth(d24);
                    }
                    if (plugin == null) continue;
                    Bukkit.getScheduler().runTaskLater(plugin, () -> {
                        if (!ironGolem.isDead()) {
                            ironGolem.remove();
                        }
                    }, (long)n18);
                }
                player.sendMessage("\u00a76[\u6a5f\u5de7\u5c04\u624b] \u00a7f\u30a2\u30a4\u30a2\u30f3\u30b4\u30fc\u30ec\u30e0 x" + n17 + " \u3092\u53ec\u559a");
                break;
            }
            case RHYTHM_DANCER: {
                int n19 = Math.min(3, (n + n2) / 40);
                int n20 = 80 + n + n2;
                double d27 = 6.0 + (double)(n + n2) * 0.03;
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, n20, n19));
                for (Entity entity : player.getNearbyEntities(d27, 3.0, d27)) {
                    if (!(entity instanceof Player)) continue;
                    Player player4 = (Player)entity;
                    player4.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, n20 - 20, Math.max(0, n19 - 0)));
                    player4.spawnParticle(Particle.NOTE, player4.getLocation().add(0.0, 1.5, 0.0), 5, 0.4, 0.3, 0.4, 0.1);
                }
                world.playSound(location, Sound.BLOCK_NOTE_BLOCK_CHIME, 1.0f, 1.2f);
                break;
            }
            case FLAME_SORCERER: {
                double d28 = 3.5 + Math.min(3.0, (double)(n + n2) * 0.02);
                Location location5 = location.clone().add(player.getLocation().getDirection().multiply(d28)).add(0.0, 1.0, 0.0);
                float f = (float)Math.min(3.5, 1.4 + (double)(n + n2) * 0.012);
                world.createExplosion(location5, f, false, false, (Entity)player);
                world.spawnParticle(Particle.FLAME, location5, 40, 1.2, 0.8, 1.2, 0.08);
                world.playSound(location5, Sound.ENTITY_GENERIC_EXPLODE, 0.9f, 1.1f);
                break;
            }
            case BEAST_SUMMONER: {
                int n21 = Math.min(6, 2 + (n + n2) / 35);
                int n22 = 200 + n * 2 + n2 * 2;
                double d29 = JobSkill.scale(n, n2, 16.0, 0.4, 0.5);
                double d30 = JobSkill.scale(n, n2, 3.0, 0.08, 0.12);
                if (CitizensSummonHelper.isAvailable()) {
                    CitizensSummonHelper.spawnMany((Player)player, (Location)location, (int)n21, (double)1.8, summonSpec -> {
                        summonSpec.name = "\u00a7a\u7363\u306e\u5f93\u8005";
                        summonSpec.hp = d29;
                        summonSpec.damage = d30;
                        summonSpec.lifeTicks = n22;
                        summonSpec.jobLevel = n;
                        summonSpec.ranged = false;
                        summonSpec.style = "melee";
                        summonSpec.helmet = new ItemStack(Material.LEATHER_HELMET);
                        summonSpec.chest = new ItemStack(Material.LEATHER_CHESTPLATE);
                        summonSpec.legs = new ItemStack(Material.LEATHER_LEGGINGS);
                        summonSpec.boots = new ItemStack(Material.LEATHER_BOOTS);
                        summonSpec.hand = new ItemStack(Material.IRON_SWORD);
                    });
                    player.sendMessage("\u00a7a[\u7363\u53ec\u559a\u58eb] \u00a7f\u5f93\u8005 x" + n21 + " \u3092\u53ec\u559a");
                    break;
                }
                for (int i = 0; i < n21; ++i) {
                    Plugin plugin;
                    Wolf wolf = (Wolf)world.spawnEntity(location.clone().add(1.0 + (double)i * 0.5, 0.0, 1.0), EntityType.WOLF);
                    wolf.setOwner((AnimalTamer)player);
                    wolf.setAdult();
                    wolf.addScoreboardTag("levelsync_summon");
                    if (wolf.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED) != null) {
                        wolf.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED).setBaseValue(0.38);
                    }
                    if (wolf.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null) {
                        wolf.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(d29);
                        wolf.setHealth(d29);
                    }
                    if ((plugin = Bukkit.getPluginManager().getPlugin("LevelSync")) == null) continue;
                    Bukkit.getScheduler().runTaskLater(plugin, () -> {
                        if (!wolf.isDead()) {
                            wolf.remove();
                        }
                    }, (long)n22);
                }
                break;
            }
            case ARCANE_DUELIST: {
                Arrow arrow = (Arrow)player.launchProjectile(Arrow.class);
                arrow.setVelocity(player.getLocation().getDirection().multiply(2.2 + Math.min(1.2, (double)(n + n2) * 0.008)));
                arrow.setDamage(JobSkill.scale(n, n2, 6.0, 0.12, 0.1));
                arrow.setColor(Color.PURPLE);
                arrow.setGlowing(true);
                arrow.setCustomName("ARCANE_SLASH");
                world.playSound(location, Sound.ENTITY_EVOKER_CAST_SPELL, 0.8f, 1.3f);
                world.spawnParticle(Particle.WITCH, location, 15, 0.5, 0.5, 0.5, 0.05);
            }
        }
        player.sendMessage("\u00a76[Job] \u00a7e" + JobSkill.getSkillName(job) + " \u00a7f\u3092\u767a\u52d5\uff01 \u00a77(JobLv." + n + " / SyncLv." + n2 + ")");
        return true;
    }

    public static Integer getLancerChain(UUID uUID) {
        return lancerChain.get(uUID);
    }

    public static int[] getLevelsPublic(Player player, Job job) {
        return JobSkill.getLevels(player, job);
    }

    private static int[] getLevels(Player player, Job job) {
        JobManager jobManager;
        int n = 1;
        int n2 = 1;
        Plugin plugin = Bukkit.getPluginManager().getPlugin("LevelSync");
        if (plugin != null) {
            try {
                jobManager = ((LevelSync)plugin).getJobManager();
                if (jobManager != null) {
                    n = Math.max(1, jobManager.getData(player).getLevel(job));
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        try {
            jobManager = AuraSkillsApi.get().getUser(player.getUniqueId());
            if (jobManager != null && jobManager.isLoaded()) {
                int n3 = jobManager.getSkillLevel((Skill)Skills.DEFENSE);
                int n4 = jobManager.getSkillLevel((Skill)Skills.FIGHTING);
                int n5 = jobManager.getSkillLevel((Skill)Skills.ARCHERY);
                n2 = Math.max(1, (n3 + n4 + n5) / 3);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return new int[]{n, n2};
    }

    private static double scale(int n, int n2, double d, double d2, double d3) {
        return d + (double)n * d2 + (double)n2 * d3;
    }

    private static LivingEntity getFrontTarget(Player player, double d) {
        Location location = player.getEyeLocation();
        Vector vector = location.getDirection().normalize();
        LivingEntity livingEntity = null;
        double d2 = d + 1.0;
        for (double d3 = 1.0; d3 <= d; d3 += 0.6) {
            Location location2 = location.clone().add(vector.clone().multiply(d3));
            for (Entity entity : player.getWorld().getNearbyEntities(location2, 1.2, 1.2, 1.2)) {
                double d4;
                if (!(entity instanceof LivingEntity)) continue;
                LivingEntity livingEntity2 = (LivingEntity)entity;
                if (entity == player || entity instanceof ArmorStand || !((d4 = livingEntity2.getLocation().distance(player.getLocation())) < d2)) continue;
                d2 = d4;
                livingEntity = livingEntity2;
            }
        }
        return livingEntity;
    }

    private static void damageInFront(Player player, double d, double d2) {
        Location location = player.getEyeLocation();
        Vector vector = location.getDirection().normalize();
        for (double d3 = 1.0; d3 <= d; d3 += 0.8) {
            Location location2 = location.clone().add(vector.clone().multiply(d3));
            Collection collection = player.getWorld().getNearbyEntities(location2, 1.1, 1.1, 1.1);
            for (Entity entity : collection) {
                if (!(entity instanceof LivingEntity)) continue;
                LivingEntity livingEntity = (LivingEntity)entity;
                if (entity == player || entity instanceof ArmorStand) continue;
                livingEntity.damage(d2, (Entity)player);
                player.getWorld().spawnParticle(Particle.CRIT, livingEntity.getLocation().add(0.0, 1.0, 0.0), 8, 0.3, 0.3, 0.3, 0.05);
            }
        }
    }

    private static void spawnShadowClone(Player player) {
        Plugin plugin = Bukkit.getPluginManager().getPlugin("LevelSync");
        if (plugin == null) {
            return;
        }
        int n = 1;
        try {
            JobManager jobManager = ((LevelSync)plugin).getJobManager();
            if (jobManager != null) {
                n = jobManager.getData(player).getLevel(Job.DARK_KNIGHT);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        int n2 = 1;
        int n3 = 1;
        int n4 = 1;
        try {
            SkillsUser skillsUser = AuraSkillsApi.get().getUser(player.getUniqueId());
            if (skillsUser != null && skillsUser.isLoaded()) {
                n2 = Math.max(1, skillsUser.getSkillLevel((Skill)Skills.DEFENSE));
                n3 = Math.max(1, skillsUser.getSkillLevel((Skill)Skills.FIGHTING));
                n4 = Math.max(1, skillsUser.getSkillLevel((Skill)Skills.ARCHERY));
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        int n5 = 1;
        int n6 = 1;
        int n7 = 1;
        try {
            UUID uUID = player.getUniqueId();
            if (PlayerData.isInMemory((Player)player)) {
                n5 = Math.max(1, PlayerData.getSkillLevel((UUID)uUID, (SkillType)SkillType.ARMOR));
                int n8 = PlayerData.getSkillLevel((UUID)uUID, (SkillType)SkillType.SWORDS);
                int n9 = PlayerData.getSkillLevel((UUID)uUID, (SkillType)SkillType.AXES);
                int n10 = PlayerData.getSkillLevel((UUID)uUID, (SkillType)SkillType.MACES);
                int n11 = PlayerData.getSkillLevel((UUID)uUID, (SkillType)SkillType.SPEARS);
                int n12 = PlayerData.getSkillLevel((UUID)uUID, (SkillType)SkillType.HOES);
                n6 = Math.max(1, Math.max(n8, Math.max(n9, Math.max(n10, Math.max(n11, n12)))));
                int n13 = PlayerData.getSkillLevel((UUID)uUID, (SkillType)SkillType.BOWS);
                int n14 = PlayerData.getSkillLevel((UUID)uUID, (SkillType)SkillType.CROSSBOWS);
                int n15 = PlayerData.getSkillLevel((UUID)uUID, (SkillType)SkillType.TRIDENTS);
                n7 = Math.max(1, Math.max(n13, Math.max(n14, n15)));
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        double d = (double)(n2 + n3 + n4 + n5 + n6 + n7) / 6.0;
        double d2 = 20.0 + (double)n * 1.2 + d * 1.5;
        double d3 = 4.0 + (double)n * 0.18 + d * 0.35;
        World world = player.getWorld();
        Location location = player.getLocation();
        PlayerInventory playerInventory = player.getInventory();
        int n16 = n >= 40 || d >= 35.0 ? 2 : 1;
        for (int i = 0; i < n16; ++i) {
            CitizensSummonHelper.SummonSpec summonSpec;
            double d4 = i == 0 ? -1.5 : 1.5;
            Vector vector = location.getDirection().clone().setY(0).normalize();
            Vector vector2 = new Vector(-vector.getZ(), 0.0, vector.getX()).normalize().multiply(d4);
            Location location2 = location.clone().add(vector2).add(vector.clone().multiply(-1.2));
            if (true) {
                summonSpec = new CitizensSummonHelper.SummonSpec();
                summonSpec.name = "\u00a78" + player.getName() + "\u306e\u5206\u8eab";
                summonSpec.ownerId = player.getUniqueId();
                summonSpec.hp = d2;
                summonSpec.damage = d3;
                summonSpec.lifeTicks = 500;
                summonSpec.jobLevel = n;
                summonSpec.ranged = false;
                summonSpec.style = "clone";
                if (playerInventory.getHelmet() != null) {
                    summonSpec.helmet = playerInventory.getHelmet().clone();
                }
                if (playerInventory.getChestplate() != null) {
                    summonSpec.chest = playerInventory.getChestplate().clone();
                }
                if (playerInventory.getLeggings() != null) {
                    summonSpec.legs = playerInventory.getLeggings().clone();
                }
                if (playerInventory.getBoots() != null) {
                    summonSpec.boots = playerInventory.getBoots().clone();
                }
                if (playerInventory.getItemInMainHand() != null && playerInventory.getItemInMainHand().getType() != Material.AIR) {
                    summonSpec.hand = playerInventory.getItemInMainHand().clone();
                }
                if (playerInventory.getItemInOffHand() != null && playerInventory.getItemInOffHand().getType() != Material.AIR) {
                    summonSpec.offhand = playerInventory.getItemInOffHand().clone();
                }
                CitizensSummonHelper.spawnHuman((Player)player, (Location)location2, (CitizensSummonHelper.SummonSpec)summonSpec);
                continue;
            }
            summonSpec = (Zombie)world.spawnEntity(location2, EntityType.ZOMBIE);
            summonSpec.setCustomName("\u00a78" + player.getName() + "\u306e\u5206\u8eab");
            summonSpec.setCustomNameVisible(true);
            summonSpec.setAdult();
            summonSpec.setSilent(true);
            summonSpec.setShouldBurnInDay(false);
            summonSpec.setCanPickupItems(false);
            summonSpec.setRemoveWhenFarAway(false);
            summonSpec.setAggressive(true);
            summonSpec.addScoreboardTag("levelsync_summon");
            summonSpec.addScoreboardTag("levelsync_owner_" + String.valueOf(player.getUniqueId()));
            EntityEquipment entityEquipment = summonSpec.getEquipment();
            if (entityEquipment != null) {
                if (playerInventory.getHelmet() != null) {
                    entityEquipment.setHelmet(playerInventory.getHelmet().clone());
                }
                if (playerInventory.getChestplate() != null) {
                    entityEquipment.setChestplate(playerInventory.getChestplate().clone());
                }
                if (playerInventory.getLeggings() != null) {
                    entityEquipment.setLeggings(playerInventory.getLeggings().clone());
                }
                if (playerInventory.getBoots() != null) {
                    entityEquipment.setBoots(playerInventory.getBoots().clone());
                }
                if (playerInventory.getItemInMainHand() != null && playerInventory.getItemInMainHand().getType() != Material.AIR) {
                    entityEquipment.setItemInMainHand(playerInventory.getItemInMainHand().clone());
                }
                if (playerInventory.getItemInOffHand() != null && playerInventory.getItemInOffHand().getType() != Material.AIR) {
                    entityEquipment.setItemInOffHand(playerInventory.getItemInOffHand().clone());
                }
                entityEquipment.setHelmetDropChance(0.0f);
                entityEquipment.setChestplateDropChance(0.0f);
                entityEquipment.setLeggingsDropChance(0.0f);
                entityEquipment.setBootsDropChance(0.0f);
                entityEquipment.setItemInMainHandDropChance(0.0f);
                entityEquipment.setItemInOffHandDropChance(0.0f);
            }
            if (summonSpec.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null) {
                summonSpec.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(d2);
                summonSpec.setHealth(d2);
            }
            SummonLevelSync.Snapshot snapshot = SummonLevelSync.capture((Player)player, (int)n);
            SummonLevelSync.applyTo((LivingEntity)summonSpec, (SummonLevelSync.Snapshot)snapshot, (boolean)false);
            double d5 = d3 = SummonLevelSync.damageFromSnapshot((SummonLevelSync.Snapshot)snapshot, (boolean)false, (double)d3);
            Bukkit.getScheduler().runTaskTimer(plugin, arg_0 -> JobSkill.lambda$spawnShadowClone$7((Zombie)summonSpec, world, d5, arg_0), 20L, 20L);
            Bukkit.getScheduler().runTaskLater(plugin, () -> JobSkill.lambda$spawnShadowClone$8((Zombie)summonSpec), 500L);
        }
        double d6 = d3;
        Bukkit.getScheduler().runTaskTimer(plugin, bukkitTask -> {
            int n = 0;
            for (Entity entity : player.getNearbyEntities(24.0, 12.0, 24.0)) {
                if (!(entity instanceof LivingEntity)) continue;
                LivingEntity livingEntity = (LivingEntity)entity;
                if (!entity.getScoreboardTags().contains("levelsync_summon") || entity.getCustomName() == null || !entity.getCustomName().contains("\u306e\u5206\u8eab") || livingEntity.isDead()) continue;
                ++n;
                for (Entity entity2 : livingEntity.getNearbyEntities(4.0, 3.0, 4.0)) {
                    if (!(entity2 instanceof LivingEntity)) continue;
                    LivingEntity livingEntity2 = (LivingEntity)entity2;
                    if (entity2 instanceof Player || JobSkillListener.isOurSummon((Entity)entity2) || livingEntity2.isDead()) continue;
                    livingEntity2.damage(d6 * 0.8, (Entity)livingEntity);
                    world.spawnParticle(Particle.SOUL, livingEntity2.getLocation().add(0.0, 0.5, 0.0), 6, 0.3, 0.3, 0.3, 0.01);
                }
            }
            if (n == 0) {
                bukkitTask.cancel();
            }
        }, 40L, 40L);
        player.sendMessage(String.format("\u00a78[\u6697\u5f71\u53cc\u8eab] \u00a77\u5206\u8eab x%d  \u00a78(Job%d / Aura D%d F%d A%d / EM Armor%d Melee%d Ranged%d)", n16, n, n2, n3, n4, n5, n6, n7));
    }

    private static void spawnUndeadSkulls(Player player) {
        WitherSkeleton witherSkeleton;
        Location location;
        double d;
        int n;
        int[] nArray = JobSkill.getLevels(player, Job.NECROMANCER);
        int n2 = nArray[0];
        int n3 = nArray[1];
        int n4 = Math.min(3, 2 + (n2 + n3) / 25);
        int n5 = Math.min(2, 1 + (n2 + n3) / 30);
        double d2 = 12.0 + (double)n2 * 0.6 + (double)n3 * 0.8;
        double d3 = 3.0 + (double)n2 * 0.12 + (double)n3 * 0.18;
        double d4 = 2.5 + (double)n2 * 0.1 + (double)n3 * 0.15;
        Location location2 = player.getLocation();
        World world = player.getWorld();
        if (CitizensSummonHelper.isAvailable()) {
            PlayerInventory playerInventory = player.getInventory();
            ItemStack itemStack = playerInventory.getHelmet() != null ? playerInventory.getHelmet().clone() : null;
            ItemStack itemStack2 = playerInventory.getChestplate() != null ? playerInventory.getChestplate().clone() : null;
            ItemStack itemStack3 = playerInventory.getLeggings() != null ? playerInventory.getLeggings().clone() : null;
            ItemStack itemStack4 = playerInventory.getBoots() != null ? playerInventory.getBoots().clone() : null;
            CitizensSummonHelper.spawnMany((Player)player, (Location)location2, (int)n4, (double)1.6, summonSpec -> {
                summonSpec.name = "\u00a78\u6b7b\u8005\u306e\u5f93\u50d5";
                summonSpec.hp = d2;
                summonSpec.damage = d3;
                summonSpec.lifeTicks = 400;
                summonSpec.jobLevel = n2;
                summonSpec.ranged = false;
                summonSpec.style = "melee";
                summonSpec.helmet = itemStack != null ? itemStack.clone() : new ItemStack(Material.WITHER_SKELETON_SKULL);
                summonSpec.chest = itemStack2 != null ? itemStack2.clone() : new ItemStack(Material.CHAINMAIL_CHESTPLATE);
                summonSpec.legs = itemStack3 != null ? itemStack3.clone() : new ItemStack(Material.CHAINMAIL_LEGGINGS);
                summonSpec.boots = itemStack4 != null ? itemStack4.clone() : new ItemStack(Material.CHAINMAIL_BOOTS);
                summonSpec.hand = new ItemStack(Material.STONE_SWORD);
            });
            CitizensSummonHelper.spawnMany((Player)player, (Location)location2, (int)n5, (double)2.2, summonSpec -> {
                summonSpec.name = "\u00a78\u5f13\u306e\u5f93\u50d5";
                summonSpec.hp = d2 * 0.85;
                summonSpec.damage = d4;
                summonSpec.lifeTicks = 400;
                summonSpec.jobLevel = n2;
                summonSpec.ranged = true;
                summonSpec.style = "ranged";
                summonSpec.helmet = itemStack != null ? itemStack.clone() : new ItemStack(Material.SKELETON_SKULL);
                summonSpec.chest = itemStack2 != null ? itemStack2.clone() : new ItemStack(Material.LEATHER_CHESTPLATE);
                summonSpec.legs = itemStack3 != null ? itemStack3.clone() : new ItemStack(Material.LEATHER_LEGGINGS);
                summonSpec.boots = itemStack4 != null ? itemStack4.clone() : new ItemStack(Material.LEATHER_BOOTS);
                summonSpec.hand = new ItemStack(Material.BOW);
            });
            player.sendMessage("\u00a78[\u6b7b\u8005\u306e\u76ee\u899a\u3081] \u00a77\u8fd1\u63a5\u5f93\u50d5 x" + n4 + " / \u5f13\u5f93\u50d5 x" + n5 + " \u3092\u53ec\u559a");
            return;
        }
        Plugin plugin = Bukkit.getPluginManager().getPlugin("LevelSync");
        for (n = 0; n < n4; ++n) {
            d = Math.PI * 2 * (double)n / (double)n4;
            location = location2.clone().add(Math.cos(d) * 1.5, 0.0, Math.sin(d) * 1.5);
            witherSkeleton = (WitherSkeleton)world.spawnEntity(location, EntityType.WITHER_SKELETON);
            witherSkeleton.setCustomName("\u00a78\u6b7b\u8005\u306e\u30c9\u30af\u30ed");
            witherSkeleton.setCustomNameVisible(true);
            witherSkeleton.addScoreboardTag("levelsync_summon");
            if (witherSkeleton.getEquipment() != null) {
                witherSkeleton.getEquipment().setItemInMainHand(new ItemStack(Material.STONE_SWORD));
                witherSkeleton.getEquipment().setItemInMainHandDropChance(0.0f);
            }
            if (witherSkeleton.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null) {
                witherSkeleton.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(d2);
                witherSkeleton.setHealth(d2);
            }
            if (plugin == null) continue;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!witherSkeleton.isDead()) {
                    witherSkeleton.remove();
                }
            }, 400L);
        }
        for (n = 0; n < n5; ++n) {
            d = Math.PI * 2 * (double)n / (double)Math.max(1, n5) + 0.7;
            location = location2.clone().add(Math.cos(d) * 2.0, 0.0, Math.sin(d) * 2.0);
            witherSkeleton = (Skeleton)world.spawnEntity(location, EntityType.SKELETON);
            witherSkeleton.setCustomName("\u00a78\u5f13\u306e\u30c9\u30af\u30ed");
            witherSkeleton.setCustomNameVisible(true);
            witherSkeleton.addScoreboardTag("levelsync_summon");
            if (witherSkeleton.getEquipment() != null) {
                witherSkeleton.getEquipment().setItemInMainHand(new ItemStack(Material.BOW));
                witherSkeleton.getEquipment().setItemInMainHandDropChance(0.0f);
            }
            if (plugin == null) continue;
            Bukkit.getScheduler().runTaskLater(plugin, () -> JobSkill.lambda$spawnUndeadSkulls$13((Skeleton)witherSkeleton), 400L);
        }
        player.sendMessage("\u00a78[\u6b7b\u8005\u306e\u76ee\u899a\u3081] \u00a77\u8fd1\u63a5\u30c9\u30af\u30ed x" + n4 + " / \u5f13\u30c9\u30af\u30ed x" + n5 + " \u3092\u53ec\u559a");
    }

    private static /* synthetic */ void lambda$spawnUndeadSkulls$13(Skeleton skeleton) {
        if (!skeleton.isDead()) {
            skeleton.remove();
        }
    }

    private static /* synthetic */ void lambda$spawnShadowClone$8(Zombie zombie) {
        if (!zombie.isDead() && zombie.isValid()) {
            zombie.remove();
        }
    }

    private static /* synthetic */ void lambda$spawnShadowClone$7(Zombie zombie, World world, double d, BukkitTask bukkitTask) {
        if (zombie.isDead() || !zombie.isValid()) {
            bukkitTask.cancel();
            return;
        }
        world.spawnParticle(Particle.SMOKE, zombie.getLocation().add(0.0, 1.0, 0.0), 4, 0.25, 0.4, 0.25, 0.01);
        LivingEntity livingEntity = null;
        double d2 = 8.0;
        for (Entity entity : zombie.getNearbyEntities(8.0, 4.0, 8.0)) {
            double d3;
            if (!(entity instanceof LivingEntity)) continue;
            LivingEntity livingEntity2 = (LivingEntity)entity;
            if (entity instanceof Player || JobSkillListener.isOurSummon((Entity)entity) || livingEntity2.isDead() || !((d3 = livingEntity2.getLocation().distance(zombie.getLocation())) < d2)) continue;
            d2 = d3;
            livingEntity = livingEntity2;
        }
        if (livingEntity != null) {
            livingEntity.damage(d, (Entity)zombie);
            world.spawnParticle(Particle.SOUL, livingEntity.getLocation().add(0.0, 1.0, 0.0), 6, 0.3, 0.4, 0.3, 0.01);
        }
    }
}
