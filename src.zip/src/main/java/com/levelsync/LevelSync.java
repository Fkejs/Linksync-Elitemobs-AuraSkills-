package com.levelsync;

import com.levelsync.job.Job;
import com.levelsync.job.JobGUI;
import com.levelsync.job.JobManager;
import com.levelsync.job.JobSkill;
import com.levelsync.job.PlayerJobData;
import com.magmaguy.elitemobs.playerdata.database.PlayerData;
import com.magmaguy.elitemobs.skills.SkillType;
import com.magmaguy.elitemobs.skills.SkillXPCalculator;
import dev.aurelium.auraskills.api.AuraSkillsApi;
import dev.aurelium.auraskills.api.event.skill.SkillLevelUpEvent;
import dev.aurelium.auraskills.api.skill.Skill;
import dev.aurelium.auraskills.api.skill.Skills;
import dev.aurelium.auraskills.api.user.SkillsUser;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

public class LevelSync
extends JavaPlugin
implements Listener,
CommandExecutor {
    private final Set<UUID> syncing = new HashSet<UUID>();
    private BukkitTask periodicTask;
    private JobManager jobManager;
    private static final List<SyncGroup> GROUPS = Arrays.asList(new SyncGroup("\u9632\u5fa1 / Defense", (Skill)Skills.DEFENSE, new SkillType[]{SkillType.ARMOR}, Material.SHIELD), new SyncGroup("\u8fd1\u63a5 / Melee", (Skill)Skills.FIGHTING, new SkillType[]{SkillType.SWORDS, SkillType.AXES, SkillType.MACES, SkillType.SPEARS, SkillType.HOES}, Material.DIAMOND_SWORD), new SyncGroup("\u9060\u9694 / Ranged", (Skill)Skills.ARCHERY, new SkillType[]{SkillType.BOWS, SkillType.CROSSBOWS, SkillType.TRIDENTS}, Material.BOW));
    private static final Skill[] NON_SYNCED_SKILLS = new Skill[]{Skills.FARMING, Skills.FORAGING, Skills.MINING, Skills.FISHING, Skills.EXCAVATION, Skills.AGILITY, Skills.ENCHANTING, Skills.ALCHEMY};
    private static final Material[] NON_SYNCED_ICONS = new Material[]{Material.WHEAT, Material.OAK_LOG, Material.DIAMOND_PICKAXE, Material.FISHING_ROD, Material.IRON_SHOVEL, Material.FEATHER, Material.ENCHANTING_TABLE, Material.BREWING_STAND};

    public JobManager getJobManager() {
        return this.jobManager;
    }

    public void onEnable() {
        if (Bukkit.getPluginManager().getPlugin("AuraSkills") == null || Bukkit.getPluginManager().getPlugin("EliteMobs") == null) {
            this.getLogger().severe("AuraSkills and EliteMobs are required! Disabling...");
            Bukkit.getPluginManager().disablePlugin((Plugin)this);
            return;
        }
        this.jobManager = new JobManager(this);
        PluginManager pluginManager = Bukkit.getPluginManager();
        PluginManager pluginManager2 = Bukkit.getPluginManager();
        Bukkit.getPluginManager().registerEvents((Listener)this, (Plugin)this);
        this.getCommand("levelsync").setExecutor((CommandExecutor)this);
        this.getCommand("levelsyncgui").setExecutor((CommandExecutor)this);
        this.periodicTask = Bukkit.getScheduler().runTaskTimer((Plugin)this, this::syncAllOnline, 200L, 200L);
        Bukkit.getScheduler().runTaskTimerAsynchronously((Plugin)this, () -> this.jobManager.saveAll(), 6000L, 6000L);
        Bukkit.getScheduler().runTaskTimer((Plugin)this, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                for (Entity entity : player.getNearbyEntities(48.0, 24.0, 48.0)) {
                    double d;
                    if (!(entity instanceof LivingEntity)) continue;
                    LivingEntity livingEntity = (LivingEntity)entity;
                    if (!entity.getScoreboardTags().contains("levelsync_summon") || livingEntity.isDead()) continue;
                    if (livingEntity instanceof Player) {
                        Player player2 = (Player)livingEntity;
                        player2.setSprinting(true);
                    }
                    if (livingEntity.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED) == null || !((d = livingEntity.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED).getBaseValue()) < 0.28)) continue;
                    livingEntity.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED).setBaseValue(0.32);
                }
            }
        }, 20L, 20L);
        this.getLogger().info("LevelSync enabled!");
        this.getLogger().info(" - Skill Sync: 3 groups");
        this.getLogger().info(" - Job System: " + Job.values().length + " jobs (FF14 style)");
    }

    public void onDisable() {
        if (this.periodicTask != null) {
            this.periodicTask.cancel();
        }
        if (this.jobManager != null) {
            this.jobManager.saveAll();
        }
        this.syncing.clear();
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onAuraLevelUp(SkillLevelUpEvent skillLevelUpEvent) {
        Skill skill = skillLevelUpEvent.getSkill();
        boolean bl = false;
        for (SyncGroup syncGroup : GROUPS) {
            if (!syncGroup.auraSkill.equals(skill)) continue;
            bl = true;
            break;
        }
        if (!bl) {
            return;
        }
        Player player = skillLevelUpEvent.getPlayer();
        if (player == null || !player.isOnline()) {
            return;
        }
        Bukkit.getScheduler().runTaskLater((Plugin)this, () -> this.syncPlayer(player), 2L);
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent playerJoinEvent) {
        Player player = playerJoinEvent.getPlayer();
        this.jobManager.getData(player);
        Bukkit.getScheduler().runTaskLater((Plugin)this, () -> {
            if (player.isOnline()) {
                this.syncPlayer(player);
                PlayerJobData playerJobData = this.jobManager.getData(player);
                player.sendMessage("\u00a76[Job] \u00a7f\u73fe\u5728\u306e\u30b8\u30e7\u30d6: \u00a7e" + playerJobData.getCurrentJob().getDisplayName() + " \u00a77(Lv." + playerJobData.getLevel(playerJobData.getCurrentJob()) + ")");
            }
        }, 40L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent playerQuitEvent) {
        this.jobManager.unload(playerQuitEvent.getPlayer().getUniqueId());
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onEntityDeath(EntityDeathEvent entityDeathEvent) {
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent inventoryClickEvent) {
        Object object = inventoryClickEvent.getWhoClicked();
        if (!(object instanceof Player)) {
            return;
        }
        Player player = (Player)object;
        object = inventoryClickEvent.getView().getTitle();
        if (((String)object).startsWith("\u00a78\u00a7lLevel Sync")) {
            inventoryClickEvent.setCancelled(true);
            ItemStack itemStack = inventoryClickEvent.getCurrentItem();
            if (itemStack == null || !itemStack.hasItemMeta()) {
                return;
            }
            String string = itemStack.getItemMeta().getDisplayName();
            if (string.contains("\u4eca\u3059\u3050\u540c\u671f") || string.contains("Force Sync")) {
                this.syncPlayer(player);
                player.sendMessage("\u00a7a\u30ec\u30d9\u30eb\u3092\u5f37\u5236\u540c\u671f\u3057\u307e\u3057\u305f\uff01");
                this.openLevelGui(player);
            } else if (string.contains("\u9589\u3058\u308b") || string.contains("Close")) {
                player.closeInventory();
            }
            return;
        }
        Object object2 = object;
    }

    private void syncAllOnline() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            this.syncPlayer(player);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void syncPlayer(Player player) {
        UUID uUID = player.getUniqueId();
        if (this.syncing.contains(uUID)) {
            return;
        }
        if (!PlayerData.isInMemory((Player)player)) {
            return;
        }
        SkillsUser skillsUser = AuraSkillsApi.get().getUser(uUID);
        if (skillsUser == null || !skillsUser.isLoaded()) {
            return;
        }
        this.syncing.add(uUID);
        try {
            for (SyncGroup syncGroup : GROUPS) {
                this.syncGroup(player, skillsUser, syncGroup);
            }
        }
        finally {
            Bukkit.getScheduler().runTaskLater((Plugin)this, () -> this.syncing.remove(uUID), 15L);
        }
    }

    private void syncGroup(Player player, SkillsUser skillsUser, SyncGroup syncGroup) {
        UUID uUID = player.getUniqueId();
        int n = skillsUser.getSkillLevel(syncGroup.auraSkill);
        HashMap<SkillType, Integer> hashMap = new HashMap<SkillType, Integer>();
        for (SkillType skillType : syncGroup.eliteSkills) {
            int n2 = PlayerData.getSkillLevel((UUID)uUID, (SkillType)skillType);
            hashMap.put(skillType, n2);
            if (n2 <= n) continue;
            n = n2;
        }
        if (n <= 0) {
            return;
        }
        int n3 = skillsUser.getSkillLevel(syncGroup.auraSkill);
        if (n3 < n) {
            skillsUser.setSkillLevel(syncGroup.auraSkill, n);
            this.getLogger().info(player.getName() + " [" + syncGroup.name + "] AuraSkills." + syncGroup.auraSkill.name() + " " + n3 + " -> " + n);
        }
        for (SkillType skillType : syncGroup.eliteSkills) {
            int n4 = (Integer)hashMap.get(skillType);
            if (n4 >= n) continue;
            long l = SkillXPCalculator.totalXPForLevel((int)n);
            PlayerData.setSkillXP((UUID)uUID, (SkillType)skillType, (long)l);
            this.getLogger().info(player.getName() + " [" + syncGroup.name + "] EliteMobs." + skillType.name() + " " + n4 + " -> " + n);
        }
    }

    public void openLevelGui(Player player) {
        Object object;
        int n;
        SyncGroup syncGroup2;
        UUID uUID = player.getUniqueId();
        SkillsUser skillsUser = AuraSkillsApi.get().getUser(uUID);
        if (skillsUser == null || !skillsUser.isLoaded() || !PlayerData.isInMemory((Player)player)) {
            player.sendMessage("\u00a7c\u30c7\u30fc\u30bf\u304c\u307e\u3060\u8aad\u307f\u8fbc\u307e\u308c\u3066\u3044\u307e\u305b\u3093\u3002\u5c11\u3057\u5f85\u3063\u3066\u304b\u3089\u518d\u5ea6\u304a\u8a66\u3057\u304f\u3060\u3055\u3044\u3002");
            return;
        }
        Inventory inventory = Bukkit.createInventory(null, (int)54, (String)"\u00a78\u00a7lLevel Sync Status");
        ItemStack itemStack = new ItemStack(Material.BOOK);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.setDisplayName("\u00a76\u00a7l\u30ec\u30d9\u30eb\u540c\u671f\u30b9\u30c6\u30fc\u30bf\u30b9");
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add("\u00a77AuraSkills \u3068 EliteMobs \u306e\u6226\u95d8\u30b9\u30ad\u30eb\u3092\u540c\u671f");
        itemMeta.setLore(arrayList);
        itemStack.setItemMeta(itemMeta);
        inventory.setItem(4, itemStack);
        ItemStack itemStack2 = new ItemStack(Material.LIME_STAINED_GLASS_PANE);
        ItemMeta itemMeta2 = itemStack2.getItemMeta();
        itemMeta2.setDisplayName("\u00a7a\u00a7l\u3010\u540c\u671f\u30b9\u30ad\u30eb\u3011");
        itemStack2.setItemMeta(itemMeta2);
        inventory.setItem(9, itemStack2);
        inventory.setItem(17, itemStack2.clone());
        int n2 = 10;
        for (SyncGroup syncGroup2 : GROUPS) {
            SkillType skillType2;
            n = skillsUser.getSkillLevel(syncGroup2.auraSkill);
            int n3 = 0;
            ArrayList<CallSite> arrayList2 = new ArrayList<CallSite>();
            for (SkillType skillType2 : syncGroup2.eliteSkills) {
                int n4 = PlayerData.getSkillLevel((UUID)uUID, (SkillType)skillType2);
                if (n4 > n3) {
                    n3 = n4;
                }
                arrayList2.add((CallSite)((Object)("\u00a7e  " + skillType2.name() + ": \u00a7f" + n4)));
            }
            int n5 = Math.max(n, n3);
            int n6 = n == n5 ? 1 : 0;
            for (SkillType skillType3 : syncGroup2.eliteSkills) {
                if (PlayerData.getSkillLevel((UUID)uUID, (SkillType)skillType3) == n5) continue;
                n6 = 0;
                break;
            }
            object = new ItemStack(syncGroup2.icon);
            skillType2 = object.getItemMeta();
            skillType2.setDisplayName((n6 != 0 ? "\u00a7a\u00a7l" : "\u00a7c\u00a7l") + syncGroup2.name);
            ArrayList<Object> arrayList3 = new ArrayList<Object>();
            arrayList3.add("");
            arrayList3.add("\u00a7bAuraSkills " + syncGroup2.auraSkill.name() + ": \u00a7f" + n);
            arrayList3.add("\u00a76EliteMobs:");
            arrayList3.addAll(arrayList2);
            arrayList3.add("");
            arrayList3.add("\u00a77\u76ee\u6a19\u30ec\u30d9\u30eb: \u00a7e" + n5);
            arrayList3.add(n6 != 0 ? "\u00a7a\u2713 \u5b8c\u5168\u306b\u540c\u671f\u6e08\u307f" : "\u00a7c\u2717 \u672a\u540c\u671f");
            skillType2.setLore(arrayList3);
            object.setItemMeta((ItemMeta)skillType2);
            inventory.setItem(n2++, (ItemStack)object);
        }
        ItemStack itemStack3 = new ItemStack(Material.ORANGE_STAINED_GLASS_PANE);
        syncGroup2 = itemStack3.getItemMeta();
        syncGroup2.setDisplayName("\u00a76\u00a7l\u3010\u540c\u671f\u5916\u30b9\u30ad\u30eb\u3011");
        itemStack3.setItemMeta((ItemMeta)syncGroup2);
        inventory.setItem(27, itemStack3);
        inventory.setItem(35, itemStack3.clone());
        n2 = 28;
        for (n = 0; n < NON_SYNCED_SKILLS.length; ++n) {
            Skill skill = NON_SYNCED_SKILLS[n];
            int n7 = skillsUser.getSkillLevel(skill);
            ItemStack itemStack4 = new ItemStack(NON_SYNCED_ICONS[n]);
            ItemMeta itemMeta3 = itemStack4.getItemMeta();
            itemMeta3.setDisplayName("\u00a7e" + skill.name());
            object = new ArrayList();
            object.add("\u00a77\u30ec\u30d9\u30eb: \u00a7f" + n7);
            object.add("\u00a78\u203b \u540c\u671f\u5bfe\u8c61\u5916");
            itemMeta3.setLore((List)object);
            itemStack4.setItemMeta(itemMeta3);
            inventory.setItem(n2++, itemStack4);
        }
        ItemStack itemStack5 = new ItemStack(Material.EMERALD);
        ItemMeta itemMeta4 = itemStack5.getItemMeta();
        itemMeta4.setDisplayName("\u00a7a\u00a7l\u4eca\u3059\u3050\u540c\u671f / Force Sync");
        itemStack5.setItemMeta(itemMeta4);
        inventory.setItem(49, itemStack5);
        ItemStack itemStack6 = new ItemStack(Material.BARRIER);
        ItemMeta itemMeta5 = itemStack6.getItemMeta();
        itemMeta5.setDisplayName("\u00a7c\u00a7l\u9589\u3058\u308b / Close");
        itemStack6.setItemMeta(itemMeta5);
        inventory.setItem(53, itemStack6);
        ItemStack itemStack7 = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        object = itemStack7.getItemMeta();
        object.setDisplayName(" ");
        itemStack7.setItemMeta((ItemMeta)object);
        for (int i = 0; i < 54; ++i) {
            if (inventory.getItem(i) != null) continue;
            inventory.setItem(i, itemStack7);
        }
        player.openInventory(inventory);
    }

    public boolean onCommand(CommandSender commandSender, Command command, String string, String[] stringArray) {
        Player player;
        String string2 = command.getName().toLowerCase();
        if (string2.equals("job") || string2.equals("jobs")) {
            if (stringArray.length >= 1 && (stringArray[0].equalsIgnoreCase("setlevel") || stringArray[0].equalsIgnoreCase("addlevel"))) {
                int n;
                Job job;
                if (!commandSender.hasPermission("levelsync.admin")) {
                    commandSender.sendMessage("\u00a7c\u6a29\u9650\u304c\u3042\u308a\u307e\u305b\u3093\u3002");
                    return true;
                }
                if (stringArray.length < 3) {
                    commandSender.sendMessage("\u00a7e\u4f7f\u3044\u65b9:");
                    commandSender.sendMessage("\u00a7f/job setlevel <\u30d7\u30ec\u30a4\u30e4\u30fc> <\u30ec\u30d9\u30eb>");
                    commandSender.sendMessage("\u00a7f/job setlevel <\u30d7\u30ec\u30a4\u30e4\u30fc> <\u30b8\u30e7\u30d6\u540d> <\u30ec\u30d9\u30eb>");
                    commandSender.sendMessage("\u00a7f/job addlevel <\u30d7\u30ec\u30a4\u30e4\u30fc> <\u5897\u52a0\u91cf>");
                    commandSender.sendMessage("\u00a7f/job addlevel <\u30d7\u30ec\u30a4\u30e4\u30fc> <\u30b8\u30e7\u30d6\u540d> <\u5897\u52a0\u91cf>");
                    return true;
                }
                Player player2 = Bukkit.getPlayer((String)stringArray[1]);
                if (player2 == null) {
                    commandSender.sendMessage("\u00a7c\u30d7\u30ec\u30a4\u30e4\u30fc\u304c\u898b\u3064\u304b\u308a\u307e\u305b\u3093: " + stringArray[1]);
                    return true;
                }
                PlayerJobData playerJobData = this.jobManager.getData(player2);
                boolean bl = stringArray[0].equalsIgnoreCase("setlevel");
                if (stringArray.length >= 4) {
                    block25: {
                        try {
                            job = Job.valueOf(stringArray[2].toUpperCase());
                        }
                        catch (IllegalArgumentException illegalArgumentException) {
                            job = null;
                            for (Job job2 : Job.values()) {
                                if (!job2.getDisplayNameJa().equalsIgnoreCase(stringArray[2]) && !job2.getDisplayNameEn().equalsIgnoreCase(stringArray[2]) && !job2.name().equalsIgnoreCase(stringArray[2])) continue;
                                job = job2;
                                break;
                            }
                            if (job != null) break block25;
                            commandSender.sendMessage("\u00a7c\u4e0d\u660e\u306a\u30b8\u30e7\u30d6: " + stringArray[2]);
                            commandSender.sendMessage("\u00a77\u4f8b: DARK_KNIGHT / \u6697\u9ed2\u9a0e\u58eb / Necromancer");
                            return true;
                        }
                    }
                    try {
                        n = Integer.parseInt(stringArray[3]);
                    }
                    catch (NumberFormatException numberFormatException) {
                        commandSender.sendMessage("\u00a7c\u6570\u5024\u304c\u4e0d\u6b63\u3067\u3059: " + stringArray[3]);
                        return true;
                    }
                }
                job = playerJobData.getCurrentJob();
                try {
                    n = Integer.parseInt(stringArray[2]);
                }
                catch (NumberFormatException numberFormatException) {
                    commandSender.sendMessage("\u00a7c\u6570\u5024\u304c\u4e0d\u6b63\u3067\u3059: " + stringArray[2]);
                    return true;
                }
                n = Math.max(1, Math.min(100, n));
                int n2 = playerJobData.getLevel(job);
                if (bl) {
                    playerJobData.setLevel(job, n);
                } else {
                    playerJobData.setLevel(job, Math.max(1, Math.min(100, n2 + n)));
                }
                this.jobManager.save(player2.getUniqueId());
                int n3 = playerJobData.getLevel(job);
                commandSender.sendMessage("\u00a7a" + player2.getName() + " \u306e \u00a7e" + job.getDisplayName() + " \u00a7a\u3092 \u00a7fLv." + n2 + " \u00a7a\u2192 \u00a7fLv." + n3 + " \u00a7a\u306b\u5909\u66f4\u3057\u307e\u3057\u305f\u3002");
                player2.sendMessage("\u00a76[Job] \u00a7e" + job.getDisplayName() + " \u00a7f\u304c\u904b\u55b6\u306b\u3088\u308a \u00a7eLv." + n3 + " \u00a7f\u306b\u306a\u308a\u307e\u3057\u305f\u3002");
                return true;
            }
            if (!(commandSender instanceof Player)) {
                commandSender.sendMessage("\u00a7c\u30d7\u30ec\u30a4\u30e4\u30fc\u306e\u307f\u4f7f\u7528\u53ef\u80fd\u3067\u3059\u3002");
                return true;
            }
            Player player3 = (Player)commandSender;
            if (stringArray.length > 0 && stringArray[0].equalsIgnoreCase("info")) {
                PlayerJobData playerJobData = this.jobManager.getData(player3);
                Job job = playerJobData.getCurrentJob();
                player3.sendMessage("\u00a76===== \u30b8\u30e7\u30d6\u60c5\u5831 =====");
                player3.sendMessage("\u00a7e\u73fe\u5728\u306e\u30b8\u30e7\u30d6: \u00a7f" + job.getDisplayName());
                player3.sendMessage("\u00a7e\u30ed\u30fc\u30eb: " + job.getRole().getDisplay());
                player3.sendMessage("\u00a7e\u30ec\u30d9\u30eb: \u00a7f" + playerJobData.getLevel(job));
                player3.sendMessage(String.format("\u00a7e\u7d4c\u9a13\u5024: \u00a7f%.1f%%", playerJobData.getXpProgressPercent(job)));
                player3.sendMessage("\u00a7e\u30b9\u30ad\u30eb: \u00a7a" + JobSkill.getSkillName(job));
                player3.sendMessage("\u00a77  " + JobSkill.getSkillDescription(job));
                player3.sendMessage("\u00a78\u767a\u52d5\u65b9\u6cd5: \u30b9\u30cb\u30fc\u30af\u3057\u306a\u304c\u3089\u53f3\u30af\u30ea\u30c3\u30af");
            }
            JobGUI.open(player3, this.jobManager);
            return true;
        }
        if (string2.equals("levelsyncgui")) {
            if (!(commandSender instanceof Player)) {
                commandSender.sendMessage("\u00a7c\u30d7\u30ec\u30a4\u30e4\u30fc\u306e\u307f\u4f7f\u7528\u53ef\u80fd\u3067\u3059\u3002");
                return true;
            }
            this.openLevelGui((Player)commandSender);
            return true;
        }
        if (!commandSender.hasPermission("levelsync.admin")) {
            commandSender.sendMessage("\u00a7c\u6a29\u9650\u304c\u3042\u308a\u307e\u305b\u3093\u3002");
            return true;
        }
        if (stringArray.length == 0) {
            if (!(commandSender instanceof Player)) {
                commandSender.sendMessage("\u00a7c\u30d7\u30ec\u30a4\u30e4\u30fc\u3092\u6307\u5b9a\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
                return true;
            }
            player = (Player)commandSender;
        } else {
            player = Bukkit.getPlayer((String)stringArray[0]);
            if (player == null) {
                commandSender.sendMessage("\u00a7c\u30d7\u30ec\u30a4\u30e4\u30fc\u304c\u898b\u3064\u304b\u308a\u307e\u305b\u3093: " + stringArray[0]);
                return true;
            }
        }
        this.syncPlayer(player);
        commandSender.sendMessage("\u00a7a" + player.getName() + " \u306e\u5168\u6226\u95d8\u30ec\u30d9\u30eb\u3092\u540c\u671f\u3057\u307e\u3057\u305f\u3002");
        if (commandSender instanceof Player) {
            this.openLevelGui(player);
        }
        return true;
    }

    private static class SyncGroup {
        final String name;
        final Skill auraSkill;
        final SkillType[] eliteSkills;
        final Material icon;

        SyncGroup(String string, Skill skill, SkillType[] skillTypeArray, Material material) {
            this.name = string;
            this.auraSkill = skill;
            this.eliteSkills = skillTypeArray;
            this.icon = material;
        }
    }
}
